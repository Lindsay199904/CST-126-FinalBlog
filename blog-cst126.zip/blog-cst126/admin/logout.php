/** 
 * User: Lindsay Blood
 * Date: 1/24/2021
 * @author linds
 * Time 10:12pm
 * for logout the blog and logout screen
 */

<?php
session_start();
/** On modifie les variable de sssion puis on les supprime ! */
$_SESSION['connect'] = false;
$_SESSION['user'] = '';
unset($_SESSION['connect']);
unset($_SESSION['user']);


header('Location:login.php');